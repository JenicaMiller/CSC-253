﻿/**
* 10 September 2018
* CSC 253
* Jenica Miller
* Calculate the Retail price of an item
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Retail_Price_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calButton_Click(object sender, EventArgs e)
        {
            //declare variables
            double wholesale;
            double markup;

            if (double.TryParse(wcTextBox.Text, out wholesale) && double.TryParse(mpTextBox.Text, out markup))
            {
                double retail;
                retail = CalculateRetail(wholesale, markup);
                retailTextBox.Text = retail.ToString("C");
            }
            else
                MessageBox.Show("Enter a valid numbers", "Invalid input");
        }

        private double CalculateRetail (double wholesale, double markup)
            {
            //variables
            double markupPercent = markup / 100;
            double retailPrice;

            //calculation equations
            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
            //clear boxes and reset focus
            wcTextBox.Clear();
            mpTextBox.Clear();
            retailTextBox.Clear();
            wcTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //exit form
            this.Close();
        }
    }
}
