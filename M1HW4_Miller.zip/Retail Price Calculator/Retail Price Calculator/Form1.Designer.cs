﻿namespace Retail_Price_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wcLabel = new System.Windows.Forms.Label();
            this.mpLabel = new System.Windows.Forms.Label();
            this.wcTextBox = new System.Windows.Forms.TextBox();
            this.mpTextBox = new System.Windows.Forms.TextBox();
            this.calButton = new System.Windows.Forms.Button();
            this.rpLabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.retailTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // wcLabel
            // 
            this.wcLabel.AutoSize = true;
            this.wcLabel.Location = new System.Drawing.Point(36, 12);
            this.wcLabel.Name = "wcLabel";
            this.wcLabel.Size = new System.Drawing.Size(65, 13);
            this.wcLabel.TabIndex = 0;
            this.wcLabel.Text = "Whole Cost:";
            // 
            // mpLabel
            // 
            this.mpLabel.AutoSize = true;
            this.mpLabel.Location = new System.Drawing.Point(36, 69);
            this.mpLabel.Name = "mpLabel";
            this.mpLabel.Size = new System.Drawing.Size(104, 13);
            this.mpLabel.TabIndex = 1;
            this.mpLabel.Text = "Markup Percentage:";
            // 
            // wcTextBox
            // 
            this.wcTextBox.Location = new System.Drawing.Point(172, 12);
            this.wcTextBox.Name = "wcTextBox";
            this.wcTextBox.Size = new System.Drawing.Size(100, 20);
            this.wcTextBox.TabIndex = 2;
            // 
            // mpTextBox
            // 
            this.mpTextBox.Location = new System.Drawing.Point(172, 69);
            this.mpTextBox.Name = "mpTextBox";
            this.mpTextBox.Size = new System.Drawing.Size(100, 20);
            this.mpTextBox.TabIndex = 3;
            // 
            // calButton
            // 
            this.calButton.Location = new System.Drawing.Point(101, 132);
            this.calButton.Name = "calButton";
            this.calButton.Size = new System.Drawing.Size(75, 23);
            this.calButton.TabIndex = 4;
            this.calButton.Text = "Calculate";
            this.calButton.UseVisualStyleBackColor = true;
            this.calButton.Click += new System.EventHandler(this.calButton_Click);
            // 
            // rpLabel
            // 
            this.rpLabel.AutoSize = true;
            this.rpLabel.Location = new System.Drawing.Point(36, 174);
            this.rpLabel.Name = "rpLabel";
            this.rpLabel.Size = new System.Drawing.Size(64, 13);
            this.rpLabel.TabIndex = 5;
            this.rpLabel.Text = "Retail Price:";
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(36, 226);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 7;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(172, 226);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // retailTextBox
            // 
            this.retailTextBox.Location = new System.Drawing.Point(172, 166);
            this.retailTextBox.Name = "retailTextBox";
            this.retailTextBox.Size = new System.Drawing.Size(100, 20);
            this.retailTextBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.retailTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.rpLabel);
            this.Controls.Add(this.calButton);
            this.Controls.Add(this.mpTextBox);
            this.Controls.Add(this.wcTextBox);
            this.Controls.Add(this.mpLabel);
            this.Controls.Add(this.wcLabel);
            this.Name = "Form1";
            this.Text = "Retail Price Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wcLabel;
        private System.Windows.Forms.Label mpLabel;
        private System.Windows.Forms.TextBox wcTextBox;
        private System.Windows.Forms.TextBox mpTextBox;
        private System.Windows.Forms.Button calButton;
        private System.Windows.Forms.Label rpLabel;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox retailTextBox;
    }
}

