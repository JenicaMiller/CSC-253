﻿namespace Tic_Tac_Toe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c1r1Button = new System.Windows.Forms.Button();
            this.c3r1Button = new System.Windows.Forms.Button();
            this.c2r1Button = new System.Windows.Forms.Button();
            this.c2r2Button = new System.Windows.Forms.Button();
            this.c3r2Button = new System.Windows.Forms.Button();
            this.c1r2Button = new System.Windows.Forms.Button();
            this.c2r3Button = new System.Windows.Forms.Button();
            this.c3r3Button = new System.Windows.Forms.Button();
            this.c1r3Button = new System.Windows.Forms.Button();
            this.ng_Button = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // c1r1Button
            // 
            this.c1r1Button.Location = new System.Drawing.Point(12, 12);
            this.c1r1Button.Name = "c1r1Button";
            this.c1r1Button.Size = new System.Drawing.Size(75, 75);
            this.c1r1Button.TabIndex = 0;
            this.c1r1Button.UseVisualStyleBackColor = true;
            this.c1r1Button.Click += new System.EventHandler(this.button_click);
            // 
            // c3r1Button
            // 
            this.c3r1Button.Location = new System.Drawing.Point(174, 12);
            this.c3r1Button.Name = "c3r1Button";
            this.c3r1Button.Size = new System.Drawing.Size(75, 75);
            this.c3r1Button.TabIndex = 1;
            this.c3r1Button.UseVisualStyleBackColor = true;
            this.c3r1Button.Click += new System.EventHandler(this.button_click);
            // 
            // c2r1Button
            // 
            this.c2r1Button.Location = new System.Drawing.Point(93, 12);
            this.c2r1Button.Name = "c2r1Button";
            this.c2r1Button.Size = new System.Drawing.Size(75, 75);
            this.c2r1Button.TabIndex = 2;
            this.c2r1Button.UseVisualStyleBackColor = true;
            this.c2r1Button.Click += new System.EventHandler(this.button_click);
            // 
            // c2r2Button
            // 
            this.c2r2Button.Location = new System.Drawing.Point(94, 93);
            this.c2r2Button.Name = "c2r2Button";
            this.c2r2Button.Size = new System.Drawing.Size(75, 75);
            this.c2r2Button.TabIndex = 5;
            this.c2r2Button.UseVisualStyleBackColor = true;
            this.c2r2Button.Click += new System.EventHandler(this.button_click);
            // 
            // c3r2Button
            // 
            this.c3r2Button.Location = new System.Drawing.Point(175, 93);
            this.c3r2Button.Name = "c3r2Button";
            this.c3r2Button.Size = new System.Drawing.Size(75, 75);
            this.c3r2Button.TabIndex = 4;
            this.c3r2Button.UseVisualStyleBackColor = true;
            this.c3r2Button.Click += new System.EventHandler(this.button_click);
            // 
            // c1r2Button
            // 
            this.c1r2Button.Location = new System.Drawing.Point(13, 93);
            this.c1r2Button.Name = "c1r2Button";
            this.c1r2Button.Size = new System.Drawing.Size(75, 75);
            this.c1r2Button.TabIndex = 3;
            this.c1r2Button.UseVisualStyleBackColor = true;
            this.c1r2Button.Click += new System.EventHandler(this.button_click);
            // 
            // c2r3Button
            // 
            this.c2r3Button.Location = new System.Drawing.Point(93, 174);
            this.c2r3Button.Name = "c2r3Button";
            this.c2r3Button.Size = new System.Drawing.Size(75, 75);
            this.c2r3Button.TabIndex = 8;
            this.c2r3Button.UseVisualStyleBackColor = true;
            this.c2r3Button.Click += new System.EventHandler(this.button_click);
            // 
            // c3r3Button
            // 
            this.c3r3Button.Location = new System.Drawing.Point(174, 174);
            this.c3r3Button.Name = "c3r3Button";
            this.c3r3Button.Size = new System.Drawing.Size(75, 75);
            this.c3r3Button.TabIndex = 7;
            this.c3r3Button.UseVisualStyleBackColor = true;
            this.c3r3Button.Click += new System.EventHandler(this.button_click);
            // 
            // c1r3Button
            // 
            this.c1r3Button.Location = new System.Drawing.Point(12, 174);
            this.c1r3Button.Name = "c1r3Button";
            this.c1r3Button.Size = new System.Drawing.Size(75, 75);
            this.c1r3Button.TabIndex = 6;
            this.c1r3Button.UseVisualStyleBackColor = true;
            this.c1r3Button.Click += new System.EventHandler(this.button_click);
            // 
            // ng_Button
            // 
            this.ng_Button.Location = new System.Drawing.Point(37, 271);
            this.ng_Button.Name = "ng_Button";
            this.ng_Button.Size = new System.Drawing.Size(75, 23);
            this.ng_Button.TabIndex = 9;
            this.ng_Button.Text = "New Game";
            this.ng_Button.UseVisualStyleBackColor = true;
            this.ng_Button.Click += new System.EventHandler(this.ng_Button_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(159, 271);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 306);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.ng_Button);
            this.Controls.Add(this.c2r3Button);
            this.Controls.Add(this.c3r3Button);
            this.Controls.Add(this.c1r3Button);
            this.Controls.Add(this.c2r2Button);
            this.Controls.Add(this.c3r2Button);
            this.Controls.Add(this.c1r2Button);
            this.Controls.Add(this.c2r1Button);
            this.Controls.Add(this.c3r1Button);
            this.Controls.Add(this.c1r1Button);
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button c1r1Button;
        private System.Windows.Forms.Button c3r1Button;
        private System.Windows.Forms.Button c2r1Button;
        private System.Windows.Forms.Button c2r2Button;
        private System.Windows.Forms.Button c3r2Button;
        private System.Windows.Forms.Button c1r2Button;
        private System.Windows.Forms.Button c2r3Button;
        private System.Windows.Forms.Button c3r3Button;
        private System.Windows.Forms.Button c1r3Button;
        private System.Windows.Forms.Button ng_Button;
        private System.Windows.Forms.Button exitButton;
    }
}

