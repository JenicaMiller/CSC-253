﻿/**
* 3 October 
* CSC 253
* Jenica Miller
* Play a friendly game of TIC TAC TOE
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class Form1 : Form
    {
        //Letting you know whos turn it is.  If true it will be X's turn.  If false it will be O's turn
        bool turn = true;
        int turn_count = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (turn)
                b.Text = "X";
            else
                b.Text = "O";
            turn = !turn;
            b.Enabled = false;
            turn_count++;

            checkforwinner();
        }
        private void checkforwinner()
        {
            bool there_is_a_winner = false;

            //check for a horizontal winner
            if ((c1r1Button.Text == c2r1Button.Text) && (c2r1Button.Text == c3r1Button.Text) && (!c1r1Button.Enabled))
                there_is_a_winner = true;
            else if ((c1r2Button.Text == c2r2Button.Text) && (c2r2Button.Text == c3r2Button.Text) && (!c1r2Button.Enabled))
                there_is_a_winner = true;
            else if ((c1r3Button.Text == c2r3Button.Text) && (c2r3Button.Text == c3r3Button.Text) && (!c1r3Button.Enabled))
                there_is_a_winner = true;

            //checking for a vertical winner
            else if ((c1r1Button.Text == c1r2Button.Text) && (c1r2Button.Text == c1r3Button.Text) && (!c1r1Button.Enabled))
                there_is_a_winner = true;
            else if ((c2r1Button.Text == c2r2Button.Text) && (c2r2Button.Text == c2r3Button.Text) && (!c2r1Button.Enabled))
                there_is_a_winner = true;
            else if ((c3r1Button.Text == c3r2Button.Text) && (c3r2Button.Text == c3r3Button.Text) && (!c3r1Button.Enabled))
                there_is_a_winner = true;

            //checking for a diagonal winner
            else if ((c1r1Button.Text == c2r2Button.Text) && (c2r2Button.Text == c3r3Button.Text) && (!c1r1Button.Enabled))
                there_is_a_winner = true;
            else if ((c3r1Button.Text == c2r2Button.Text) && (c2r2Button.Text == c1r3Button.Text) && (!c3r1Button.Enabled))
                there_is_a_winner = true;

            //determing the winner
            if (there_is_a_winner)
            {
                //disableButtons();

                String winner = "";
                if (turn)
                    winner = "O";
                else
                    winner = "X";

                MessageBox.Show(winner + " is the WINNER :)");
            }

            else
            {
                if (turn_count == 9)
                    MessageBox.Show("It's a DRAW :(");
            }

        }

        private void disableButtons()
            {
            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = false;

                }
            }
            catch { }
            
        }

        private void ng_Button_Click(object sender, EventArgs e)
        {
            //Clear form for a new game
            turn = true;
            turn_count = 0;

            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = true;
                    b.Text = "";
                }
            }
            catch { }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //close this form
            this.Close();
        }
    }
}
