﻿namespace Kinetic_Energy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.massLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.velocityLabel = new System.Windows.Forms.Label();
            this.velTextBox = new System.Windows.Forms.TextBox();
            this.calButton = new System.Windows.Forms.Button();
            this.keLabel = new System.Windows.Forms.Label();
            this.kineticEngeryLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // massLabel
            // 
            this.massLabel.AutoSize = true;
            this.massLabel.Location = new System.Drawing.Point(62, 60);
            this.massLabel.Name = "massLabel";
            this.massLabel.Size = new System.Drawing.Size(32, 13);
            this.massLabel.TabIndex = 0;
            this.massLabel.Text = "Mass";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 1;
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(100, 53);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 20);
            this.massTextBox.TabIndex = 2;
            // 
            // velocityLabel
            // 
            this.velocityLabel.AutoSize = true;
            this.velocityLabel.Location = new System.Drawing.Point(50, 93);
            this.velocityLabel.Name = "velocityLabel";
            this.velocityLabel.Size = new System.Drawing.Size(44, 13);
            this.velocityLabel.TabIndex = 3;
            this.velocityLabel.Text = "Velocity";
            // 
            // velTextBox
            // 
            this.velTextBox.Location = new System.Drawing.Point(100, 85);
            this.velTextBox.Name = "velTextBox";
            this.velTextBox.Size = new System.Drawing.Size(100, 20);
            this.velTextBox.TabIndex = 4;
            // 
            // calButton
            // 
            this.calButton.Location = new System.Drawing.Point(113, 122);
            this.calButton.Name = "calButton";
            this.calButton.Size = new System.Drawing.Size(75, 23);
            this.calButton.TabIndex = 5;
            this.calButton.Text = "Calculate";
            this.calButton.UseVisualStyleBackColor = true;
            this.calButton.Click += new System.EventHandler(this.calButton_Click);
            // 
            // keLabel
            // 
            this.keLabel.AutoSize = true;
            this.keLabel.Location = new System.Drawing.Point(19, 195);
            this.keLabel.Name = "keLabel";
            this.keLabel.Size = new System.Drawing.Size(75, 13);
            this.keLabel.TabIndex = 6;
            this.keLabel.Text = "Kinetic Energy";
            // 
            // kineticEngeryLabel
            // 
            this.kineticEngeryLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.kineticEngeryLabel.Location = new System.Drawing.Point(100, 185);
            this.kineticEngeryLabel.Name = "kineticEngeryLabel";
            this.kineticEngeryLabel.Size = new System.Drawing.Size(100, 23);
            this.kineticEngeryLabel.TabIndex = 7;
            this.kineticEngeryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(53, 241);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(153, 241);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 276);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.kineticEngeryLabel);
            this.Controls.Add(this.keLabel);
            this.Controls.Add(this.calButton);
            this.Controls.Add(this.velTextBox);
            this.Controls.Add(this.velocityLabel);
            this.Controls.Add(this.massTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.massLabel);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label massLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.Label velocityLabel;
        private System.Windows.Forms.TextBox velTextBox;
        private System.Windows.Forms.Button calButton;
        private System.Windows.Forms.Label keLabel;
        private System.Windows.Forms.Label kineticEngeryLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

