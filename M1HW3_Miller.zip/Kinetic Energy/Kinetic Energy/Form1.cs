﻿/**
* 6 September 2018
* CSC 253
*Jenica Miller
* Calculate the kinetic energy
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kinetic_Energy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calButton_Click(object sender, EventArgs e)
        {
            //Declare variables for mass and velocity
            double m;
            double v;

            //Get the User's Input to Calculate the total amout of Kinetic Engery
            if (double.TryParse(massTextBox.Text, out m) && double.TryParse(velTextBox.Text, out v))
            {
                double KE = KineticEnergy(m, v);

                //Displays the output
                kineticEngeryLabel.Text = KE.ToString("n");
            }
            else

                //Displays an error message if there is an invalid input
                MessageBox.Show("Invalid Input, input correct value");

        }
        private double KineticEnergy(double m, double v)
        {
            //Calculates the total Kinetic Energy
            double KE = 0.5 * m * Math.Pow(v, 2);
            return KE;

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears out inputted data
            massTextBox.Clear();
            velTextBox.Clear();

            //Places curser back to Mass Text Box
            this.massTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close out form
            this.Close();
        }
    }
}
