﻿/**
* 18 October 2018
* CSC 253
* Jenica Miller
* Finding the sum of numbers using a string
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sum_of_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //accumulator
            double total = 0;

            //get the user's input
            string str = stringTextBox.Text;

            //create an array
            char[] delim = { ',' };

            //tokenize the input
            string[] tokens = str.Split(delim);

            //calculate the total
            foreach (string s in tokens)
            {
                total += double.Parse(s);
            }

            //display the total
            totalLabel.Text = total.ToString("n1");
        }
    }
}
