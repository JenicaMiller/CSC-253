﻿/**
* 23 October 2018
* CSC 253
* Jenica Miller
* Create a program for the employee and production workers class
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_Production_Worker_Classes
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        //Get input
        private void diplayButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text;
            int id = Convert.ToInt32(idTextBox.Text);
            int shift = Convert.ToInt32(shiftTextBox.Text);
            decimal pay = Convert.ToDecimal(payTextBox.Text);

            ProductionWorker worker = new ProductionWorker(name, id, shift, pay);
            outputTextBox.Text = worker.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear form
            outputTextBox.Clear();
            nameTextBox.Clear();
            idTextBox.Clear();
            shiftTextBox.Clear();
            payTextBox.Clear();

            //change focus
            nameTextBox.Focus();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //exit form
            this.Close();
        }
    }
}
