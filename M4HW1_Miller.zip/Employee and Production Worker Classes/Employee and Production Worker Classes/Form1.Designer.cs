﻿namespace Employee_and_Production_Worker_Classes
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.employeeIDLabel = new System.Windows.Forms.Label();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumLabel = new System.Windows.Forms.Label();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayLabel = new System.Windows.Forms.Label();
            this.payTextBox = new System.Windows.Forms.TextBox();
            this.diplayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // employeeLabel
            // 
            this.employeeLabel.AutoSize = true;
            this.employeeLabel.Location = new System.Drawing.Point(19, 23);
            this.employeeLabel.Name = "employeeLabel";
            this.employeeLabel.Size = new System.Drawing.Size(87, 13);
            this.employeeLabel.TabIndex = 0;
            this.employeeLabel.Text = "Employee Name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(149, 16);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // employeeIDLabel
            // 
            this.employeeIDLabel.AutoSize = true;
            this.employeeIDLabel.Location = new System.Drawing.Point(19, 60);
            this.employeeIDLabel.Name = "employeeIDLabel";
            this.employeeIDLabel.Size = new System.Drawing.Size(70, 13);
            this.employeeIDLabel.TabIndex = 2;
            this.employeeIDLabel.Text = "Employee ID:";
            // 
            // idTextBox
            // 
            this.idTextBox.Location = new System.Drawing.Point(149, 53);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(100, 20);
            this.idTextBox.TabIndex = 3;
            // 
            // shiftNumLabel
            // 
            this.shiftNumLabel.AutoSize = true;
            this.shiftNumLabel.Location = new System.Drawing.Point(19, 95);
            this.shiftNumLabel.Name = "shiftNumLabel";
            this.shiftNumLabel.Size = new System.Drawing.Size(71, 13);
            this.shiftNumLabel.TabIndex = 4;
            this.shiftNumLabel.Text = "Shift Number:";
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(149, 87);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.shiftTextBox.TabIndex = 5;
            // 
            // hourlyPayLabel
            // 
            this.hourlyPayLabel.AutoSize = true;
            this.hourlyPayLabel.Location = new System.Drawing.Point(19, 132);
            this.hourlyPayLabel.Name = "hourlyPayLabel";
            this.hourlyPayLabel.Size = new System.Drawing.Size(61, 13);
            this.hourlyPayLabel.TabIndex = 6;
            this.hourlyPayLabel.Text = "Hourly Pay:";
            // 
            // payTextBox
            // 
            this.payTextBox.Location = new System.Drawing.Point(149, 124);
            this.payTextBox.Name = "payTextBox";
            this.payTextBox.Size = new System.Drawing.Size(100, 20);
            this.payTextBox.TabIndex = 7;
            // 
            // diplayButton
            // 
            this.diplayButton.Location = new System.Drawing.Point(19, 169);
            this.diplayButton.Name = "diplayButton";
            this.diplayButton.Size = new System.Drawing.Size(75, 23);
            this.diplayButton.TabIndex = 8;
            this.diplayButton.Text = "Display";
            this.diplayButton.UseVisualStyleBackColor = true;
            this.diplayButton.Click += new System.EventHandler(this.diplayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(181, 169);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(22, 210);
            this.outputTextBox.Multiline = true;
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(225, 149);
            this.outputTextBox.TabIndex = 11;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(100, 169);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 12;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(269, 371);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.diplayButton);
            this.Controls.Add(this.payTextBox);
            this.Controls.Add(this.hourlyPayLabel);
            this.Controls.Add(this.shiftTextBox);
            this.Controls.Add(this.shiftNumLabel);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.employeeIDLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.employeeLabel);
            this.Name = "form1";
            this.Text = "Employee and Production Classes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employeeLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label employeeIDLabel;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.Label shiftNumLabel;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.Label hourlyPayLabel;
        private System.Windows.Forms.TextBox payTextBox;
        private System.Windows.Forms.Button diplayButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Button clearButton;
    }
}

