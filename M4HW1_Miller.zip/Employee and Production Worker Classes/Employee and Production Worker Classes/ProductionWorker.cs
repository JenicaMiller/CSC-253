﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_Production_Worker_Classes
{
    public class ProductionWorker : Employee
    {
        //creating constructor
        public ProductionWorker (string name, int id, int shift, decimal hourlypay) : base (name, id)
        {
            ShiftNumber = shift;
            HourlyPay = hourlypay;
        }
        //setting properties
        public int ShiftNumber { get; set; }
        public decimal HourlyPay { get; set; }

        //display properties
        public override string ToString()
        {
            return base.ToString() + 
                "Worker Shift: " + ShiftNumber + "\r\n" +
                "Worker Hourly Pay: " + HourlyPay + "\r\n";
        }

    }
}
