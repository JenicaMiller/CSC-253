﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_Production_Worker_Classes
{
    public class Employee
    {
        //creating the constructor
        public Employee (string name, int id)
        {
            EmployeeName = name;
            EmployeeNumber = id;
        }
        //setting the properties
        public string EmployeeName { get; set; }
        public int EmployeeNumber { get; set; }


        //display properties
        public override string ToString()
        {
            return "Employee Name: " + EmployeeName + "\r\n" +
                "Employee ID: " + EmployeeNumber + "\r\n";
        }
    }
}
