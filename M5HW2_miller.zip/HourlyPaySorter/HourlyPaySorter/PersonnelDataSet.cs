﻿namespace HourlyPaySorter
{


    partial class PersonnelDataSet
    {
    }
}

namespace HourlyPaySorter.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
