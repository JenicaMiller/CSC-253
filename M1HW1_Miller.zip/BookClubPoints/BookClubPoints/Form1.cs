﻿/*
 * 31 August 2018
 * CSC-253
 * Jenica Miller
 * Program to determing how many points earned by the number of books purchased
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookClubPoints
{
    public partial class BookClubPoints : Form
    {
        //Declare Variable
        int numberOfBooks;

        public BookClubPoints()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Determine how mnay points earned by the number of books purchased.
            try
            {
                numberOfBooks = int.Parse(booksTextBox.Text);

                if (numberOfBooks == 0)
                {
                    MessageBox.Show("You have earned 0 points");
                }

                if (numberOfBooks == 1)
                {
                    MessageBox.Show("You have earned 5 points");
                }

                if (numberOfBooks == 2)
                {
                    MessageBox.Show("You have earned 15 points");
                }

                if (numberOfBooks == 3)
                {
                    MessageBox.Show("You have earned 30 points");
                }

                if (numberOfBooks >= 4)
                {
                    MessageBox.Show("You have earned 60 points");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("You must enter a valid number!");
            }
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the number of books box.
            booksTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit out of form.
            this.Close();
        }
    }
}
