﻿namespace Word_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.phraseLabel = new System.Windows.Forms.Label();
            this.phraseTextBox = new System.Windows.Forms.TextBox();
            this.wcButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // phraseLabel
            // 
            this.phraseLabel.AutoSize = true;
            this.phraseLabel.Location = new System.Drawing.Point(12, 40);
            this.phraseLabel.Name = "phraseLabel";
            this.phraseLabel.Size = new System.Drawing.Size(132, 13);
            this.phraseLabel.TabIndex = 0;
            this.phraseLabel.Text = "Enter Phrase or Sentence:";
            // 
            // phraseTextBox
            // 
            this.phraseTextBox.Location = new System.Drawing.Point(150, 33);
            this.phraseTextBox.Name = "phraseTextBox";
            this.phraseTextBox.Size = new System.Drawing.Size(353, 20);
            this.phraseTextBox.TabIndex = 1;
            // 
            // wcButton
            // 
            this.wcButton.Location = new System.Drawing.Point(150, 83);
            this.wcButton.Name = "wcButton";
            this.wcButton.Size = new System.Drawing.Size(75, 23);
            this.wcButton.TabIndex = 2;
            this.wcButton.Text = "Word Count";
            this.wcButton.UseVisualStyleBackColor = true;
            this.wcButton.Click += new System.EventHandler(this.wcButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(286, 83);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(420, 83);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 139);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.wcButton);
            this.Controls.Add(this.phraseTextBox);
            this.Controls.Add(this.phraseLabel);
            this.Name = "Form1";
            this.Text = "Word Counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label phraseLabel;
        private System.Windows.Forms.TextBox phraseTextBox;
        private System.Windows.Forms.Button wcButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

