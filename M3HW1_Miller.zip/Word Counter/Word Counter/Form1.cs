﻿/**
* 6 Oct 18
* CSC 253
* Jenica Miller
* Counting the number of words excluding whitespace
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void wcButton_Click(object sender, EventArgs e)
        {
            //set to remove any white space before or after the phrase/sentence.
            string words = phraseTextBox.Text.Trim();
            MessageBox.Show("Number of Words: " + CountWords(words));
        }
        //method used to count the words
        private int CountWords(string words)
        {
            string[] allWords = words.Split(' ');
            return allWords.Length;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear this form
            phraseTextBox.Clear();

            //set the focus
            phraseTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
