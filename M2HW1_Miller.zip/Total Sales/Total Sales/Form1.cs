﻿/**
 *30 September 2018
 * CSC-253
 * Jenica Miller
 * Getting to total number of sales
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Getting the program to read all the lines in the attached text file
            try
            {
                string[] allines = File.ReadAllLines("Sales.txt");
                double[] numbers = new double[allines.Length];
                int counter = 0;
                double sum = 0;

                //get the numbers from all the lines in the file
                foreach (string value in allines)
                {
                    numbers[counter] = Convert.ToDouble(value);
                    sum += numbers[counter];
                    totalsListBox.Items.Add(numbers[counter]);
                    counter++;
                }
                //add the numbers together and display the correct sum
                totalsListBox.Items.Add("\nTotal: " + sum.ToString("n"));
            }
            catch (Exception ex)
            {
                //Display error message if incorrect data is received
                MessageBox.Show(ex.Message);
            }
            }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
    }

