﻿/**
* 18 October 2018
* CSC 253
* Jenica Miller
* Capitalize the first word in each sentence.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Capitalizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            //declare variable
            bool Upper = true;

            //if there is a punctuation the program will capitalize letter after punctuation.
            foreach(char c in sentenceTextBox.Text)
            {
                if (Upper == true)
                {
                    if (c == ' ')
                    {
                        displayTextBox.Text += c;
                        continue;
                    }
                    displayTextBox.Text += c.ToString().ToUpper();
                    Upper = false;
                    }
                else
                {
                    displayTextBox.Text += c;
}
                if (c == '?' || c == '!' || c == '.')
                    Upper = true;
                }
            }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear form
            sentenceTextBox.Clear();
            displayTextBox.Clear();
        }

        private void exitButon_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();

        }
    }
    }

